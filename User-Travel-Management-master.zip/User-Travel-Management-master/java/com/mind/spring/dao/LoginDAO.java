package com.mind.spring.dao;

import com.mind.spring.model.Login;

public interface LoginDAO {

	public Login validateUser(Login login);
	
}
